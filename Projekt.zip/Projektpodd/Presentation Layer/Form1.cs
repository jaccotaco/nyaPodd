﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ServiceModel.Syndication;
using System.Xml;
using System.IO;
using Projektpodd.Presentation_Layer;

namespace Projektpodd
{
    public partial class Form1 : Form
    {
        public string podd { get; set; }
        public object SelectedItem { get; set; }
        public string beskrivning { get; set; }
        public string feed { get; set; }
        private poddcastGet Podd = new poddcastGet();
        

        public Form1()
        {
            InitializeComponent();
            if (File.Exists("ListBoxItems.xml"))
            {
                using (StreamReader sr = new StreamReader("ListBoxItems.xml"))
                {
                    while (sr.Peek() != -1)
                    {
                        lstKategorier.Items.Add(sr.ReadLine());
                    }
                }
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CreateXML();
        }

        public void btnLaggTillPodd_Click(object sender, EventArgs e)
        {

            try
            {

                string url = podd;
                XmlReader reader = XmlReader.Create(url);
                SyndicationFeed feed = SyndicationFeed.Load(reader);
                reader.Close();

                var titel = feed.Title.Text;
                listPodd.Items.Add(titel);

                foreach(SyndicationItem item in feed.Items)
                {

                    var avsnitt = item.Title.Text;
                    listAvsnitt.Items.Add(avsnitt);


                }
               

            }
            catch (Exception)
            {
                MessageBox.Show("Inte en giltig URL");
            }
            /*
            string url = podd;
            var reader = XmlReader.Create(url);
            reader.ReadToDescendant("item");
            do
            {
                reader.ReadStartElement("item");
                var title = reader.ReadElementContentAsString();
                Console.WriteLine(title);
            } while (reader.ReadToNextSibling("item"));

            
            try
                { 
            string url = podd;
            var reader = XmlReader.Create(url);
            reader.ReadToDescendant("item");
                SyndicationFeed feed = SyndicationFeed.Load(reader);
                reader.Close();
                

                foreach (SyndicationItem item in feed.Items)
                {
                    string avsnitt = 
                    listPodd.Items.Add(avsnitt);
                } 
            }
            catch (Exception)
            {
                MessageBox.Show("Inte en giltig URL");
            }

            
            try
            {
                string url = podd;
                XmlReader reader = XmlReader.Create(url);
                SyndicationFeed feed = SyndicationFeed.Load(reader);
                reader.Close();
                foreach (SyndicationItem item in feed.Items)
                {
                    string avsnitt = item.Summary.Text;
                    lstBeskrivning.Items.Add(avsnitt);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Inte en giltig URL");
            }

            */



        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {
            podd = textBox1.Text;


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void nyKategori_Click(object sender, EventArgs e)
        {
            lstKategorier.Items.Add(txtBoxKategorier.Text);
            using (StreamWriter sw = new StreamWriter("ListBoxItems.xml", true))
            {
                sw.WriteLine(txtBoxKategorier.Text);
                
            }
            this.txtBoxKategorier.Clear();
            string[] lineOfContents = File.ReadAllLines("ListBoxItems.xml");
            foreach (var line in lineOfContents)
            {
                string[] tokens = line.Split(',');
                comboBox2.Items.Add(tokens[0]);
            }
            

        }

        private void lstKategorier_SelectedIndexChanged(object sender, EventArgs e)
        {
            string curItem = lstKategorier.SelectedItems.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            /*
            var selected_items = lstKategorier.SelectedItems.Cast<ListViewItem>();
            File.WriteAllLines("ListBoxItems.txt", selected_items.Select(lvi => lvi.Text));
            foreach (var lvi in selected_items) lstKategorier.Items.Remove(lvi);
            */

            foreach (var lvi in lstKategorier.SelectedItems.Cast<ListViewItem>()) lstKategorier.Items.Remove(lvi);
            File.WriteAllLines("ListBoxItems.xml", lstKategorier.Items.Cast<ListViewItem>().Select(lvi => lvi.Text + "," + lvi.SubItems[0].Text));
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

                   

         

            try
            {
                

                string url = podd;
                XmlReader reader = XmlReader.Create(url);
                SyndicationFeed feed = SyndicationFeed.Load(reader);
                reader.Close();   
                
                foreach (SyndicationItem item in feed.Items)
                {
                    
                    String text = listAvsnitt.SelectedItems[0].Text;
                    string avsnitt = item.Summary.Text;
                    lstBeskrivning.Items.Add(avsnitt);

                    //Matcha avsnittet och få fram summary från just det avsnittet.
                    
                      
                    
                    if (listAvsnitt.InvokeRequired.Equals(text.ToString()))
                    {
                        lstBeskrivning.Items.Add(avsnitt);
                        break;  
                    }
                    
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Inte en giltig URL");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string url = podd;
                XmlReader reader = XmlReader.Create(url);
                SyndicationFeed feed = SyndicationFeed.Load(reader);
                reader.Close();
                foreach (SyndicationItem item in feed.Items)
                {
                    string avsnitt = item.Title.Text;
                    listAvsnitt.Items.Add(avsnitt);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Inte en giltig URL");
            }
        }
        public void CreateXML()
        {
            XmlTextWriter xWriter = new XmlTextWriter("C:\\Users\\filip\\Desktop\\PoddProjekt.xml", Encoding.UTF8);
            xWriter.Formatting = Formatting.Indented;
            xWriter.WriteStartElement("Poddcast");
            xWriter.WriteStartElement("Info");
            xWriter.WriteStartElement("Titel");
            xWriter.WriteString("Podd");
            xWriter.WriteEndElement();
            xWriter.WriteStartElement("Kateogri");
            xWriter.WriteString("Info");
            xWriter.WriteEndElement();
            xWriter.WriteEndElement();
            xWriter.WriteEndElement();
            xWriter.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load("C:\\Users\\filip\\Desktop\\PoddProjekt.xml");
            XmlNode info = doc.CreateElement("Info");
            XmlNode titeln = doc.CreateElement("Titel");
            XmlNode kategori = doc.CreateElement("Kategori");

            string url = podd;
            XmlReader reader = XmlReader.Create(url);
            SyndicationFeed feed = SyndicationFeed.Load(reader);
            reader.Close();

            var titel = feed.Title.Text;

            titeln.InnerText = titel;
            info.AppendChild(titeln);
            doc.DocumentElement.AppendChild(info);

            kategori.InnerText = txtBoxKategorier.Text;
            info.AppendChild(kategori);
            doc.DocumentElement.AppendChild(info);

            doc.Save("C:\\Users\\filip\\Desktop\\PoddProjekt.xml");

            lstKategorier.Items.Add(txtBoxKategorier.Text);
            using (StreamWriter sw = new StreamWriter("ListBoxItems.xml", true))
            {
                sw.WriteLine(txtBoxKategorier.Text);

            }
                                                  
        }

        private void listPodd_MouseClick(object sender, MouseEventArgs e)
        {
            var firstSelectedItem = listPodd.SelectedItems[0];
            var selectedItem = firstSelectedItem.Text;
            string url = podd;
            XmlReader reader = XmlReader.Create(url);
            SyndicationFeed feed = SyndicationFeed.Load(reader);
            reader.Close();

            var beskrivning = feed.Description.Text;
            lstBeskrivning.Items.Add(beskrivning);



        }

        private void listAvsnitt_MouseClick(object sender, MouseEventArgs e)
        {
            string url = podd;
            XmlReader reader = XmlReader.Create(url);
            SyndicationFeed feed = SyndicationFeed.Load(reader);
            reader.Close();

            var SelectedItem = listAvsnitt.SelectedItems[0];
            var chosenItem = SelectedItem.Text;
            foreach (SyndicationItem item in feed.Items)
            {

                var avsnitt = item.Title.Text;
                //listAvsnitt.Items.Add(avsnitt);
                if (chosenItem.Equals(avsnitt))
                {
                    MessageBox.Show(avsnitt);
                    var titel = feed.Description.Text;
                    lstBeskrivning.Items.Add(titel);

                }


            }
        }
    }
    }


