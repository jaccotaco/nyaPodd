﻿namespace Projektpodd
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listPodd = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.lblUrl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnLaggTillPodd = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.listAvsnitt = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.lstKategorier = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label4 = new System.Windows.Forms.Label();
            this.txtBoxKategorier = new System.Windows.Forms.TextBox();
            this.nyKategori = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.lstBeskrivning = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // listPodd
            // 
            this.listPodd.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.listPodd.Location = new System.Drawing.Point(12, 12);
            this.listPodd.Name = "listPodd";
            this.listPodd.Size = new System.Drawing.Size(551, 191);
            this.listPodd.TabIndex = 0;
            this.listPodd.UseCompatibleStateImageBehavior = false;
            this.listPodd.View = System.Windows.Forms.View.Details;
            this.listPodd.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.listPodd.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listPodd_MouseClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Namn";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 231);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(297, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(315, 231);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(442, 230);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 3;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // lblUrl
            // 
            this.lblUrl.AutoSize = true;
            this.lblUrl.Location = new System.Drawing.Point(13, 210);
            this.lblUrl.Name = "lblUrl";
            this.lblUrl.Size = new System.Drawing.Size(32, 13);
            this.lblUrl.TabIndex = 4;
            this.lblUrl.Text = "URL:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(312, 210);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Uppdateringsintervall";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(439, 210);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Kategori";
            // 
            // btnLaggTillPodd
            // 
            this.btnLaggTillPodd.Location = new System.Drawing.Point(12, 258);
            this.btnLaggTillPodd.Name = "btnLaggTillPodd";
            this.btnLaggTillPodd.Size = new System.Drawing.Size(132, 23);
            this.btnLaggTillPodd.TabIndex = 7;
            this.btnLaggTillPodd.Text = "Lägg till Poddcast";
            this.btnLaggTillPodd.UseVisualStyleBackColor = true;
            this.btnLaggTillPodd.Click += new System.EventHandler(this.btnLaggTillPodd_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(488, 258);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Ta bort";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(407, 258);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Spara";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // listAvsnitt
            // 
            this.listAvsnitt.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3});
            this.listAvsnitt.Location = new System.Drawing.Point(12, 325);
            this.listAvsnitt.Name = "listAvsnitt";
            this.listAvsnitt.Size = new System.Drawing.Size(551, 218);
            this.listAvsnitt.TabIndex = 10;
            this.listAvsnitt.UseCompatibleStateImageBehavior = false;
            this.listAvsnitt.View = System.Windows.Forms.View.Details;
            this.listAvsnitt.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged_1);
            this.listAvsnitt.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listAvsnitt_MouseClick);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Avsnitt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 306);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Podcast \"\" Avsnitt:";
            // 
            // lstKategorier
            // 
            this.lstKategorier.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2});
            this.lstKategorier.Location = new System.Drawing.Point(583, 32);
            this.lstKategorier.Name = "lstKategorier";
            this.lstKategorier.Size = new System.Drawing.Size(242, 191);
            this.lstKategorier.TabIndex = 12;
            this.lstKategorier.UseCompatibleStateImageBehavior = false;
            this.lstKategorier.View = System.Windows.Forms.View.Details;
            this.lstKategorier.SelectedIndexChanged += new System.EventHandler(this.lstKategorier_SelectedIndexChanged);
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Kategorier";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(583, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Kategorier";
            // 
            // txtBoxKategorier
            // 
            this.txtBoxKategorier.Location = new System.Drawing.Point(586, 230);
            this.txtBoxKategorier.Name = "txtBoxKategorier";
            this.txtBoxKategorier.Size = new System.Drawing.Size(239, 20);
            this.txtBoxKategorier.TabIndex = 14;
            this.txtBoxKategorier.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // nyKategori
            // 
            this.nyKategori.Location = new System.Drawing.Point(586, 257);
            this.nyKategori.Name = "nyKategori";
            this.nyKategori.Size = new System.Drawing.Size(75, 23);
            this.nyKategori.TabIndex = 15;
            this.nyKategori.Text = "Ny";
            this.nyKategori.UseVisualStyleBackColor = true;
            this.nyKategori.Click += new System.EventHandler(this.nyKategori_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(668, 258);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 16;
            this.button4.Text = "Spara";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(750, 257);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 17;
            this.button5.Text = "Ta bort";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // lstBeskrivning
            // 
            this.lstBeskrivning.FormattingEnabled = true;
            this.lstBeskrivning.Location = new System.Drawing.Point(586, 325);
            this.lstBeskrivning.Name = "lstBeskrivning";
            this.lstBeskrivning.Size = new System.Drawing.Size(239, 225);
            this.lstBeskrivning.TabIndex = 18;
            this.lstBeskrivning.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1116, 601);
            this.Controls.Add(this.lstBeskrivning);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.nyKategori);
            this.Controls.Add(this.txtBoxKategorier);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lstKategorier);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listAvsnitt);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnLaggTillPodd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblUrl);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.listPodd);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listPodd;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label lblUrl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Button btnLaggTillPodd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListView listAvsnitt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView lstKategorier;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBoxKategorier;
        private System.Windows.Forms.Button nyKategori;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ListBox lstBeskrivning;
    }
}

